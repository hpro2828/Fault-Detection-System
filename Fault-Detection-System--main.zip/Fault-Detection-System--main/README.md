# Fault-Detection-System-
AUTHOR - DEVELOPED BY: **_AKSHAYSRIVATS VIJAYARAGHAVAN_**
Implement a Fault Detection System which, detects and eliminates the faulty products based on the shape/colour.
● Please go through the below link for more understanding
● Resources: link1
● Task submission:
1. Host the code on GitHub Repository (public).
2. Record the code and output in a video.
3. Post the video on YouTube. 
4. Share links of code (GitHub) and video (YouTube) as a post on YOUR LinkedIn profile. 
5. Submit the LinkedIn link in Task Submission Form when shared with you.
6. Please read FAQs on how to submit the tasks.
